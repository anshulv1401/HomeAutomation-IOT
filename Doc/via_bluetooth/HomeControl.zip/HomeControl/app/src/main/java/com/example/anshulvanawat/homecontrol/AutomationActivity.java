package com.example.anshulvanawat.homecontrol;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;
import android.widget.ToggleButton;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;


public class AutomationActivity extends AppCompatActivity {

    ToggleButton btn1, btn2,btn3,btn4,btn5;
    Button btnDis;

    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    int state;
    OutputStream mmOutputStream;
    InputStream mmInputStream;

    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the ledControl
        setContentView(R.layout.activity_automation);

        //call the widgtes
        btn1 = (ToggleButton) findViewById(R.id.toggleButton1);
        btn2 = (ToggleButton) findViewById(R.id.ToggleButton01);
        btn3 = (ToggleButton) findViewById(R.id.ToggleButton02);
        btn4 = (ToggleButton) findViewById(R.id.ToggleButton03);
        btn5 = (ToggleButton) findViewById(R.id.ToggleButton04);
        btnDis=(Button) findViewById(R.id.btndis);



        new ConnectBT().execute(); //Call the class to connect

        //commands to be sent to bluetooth
        btn1.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (btn1.isChecked()) {
                    if (state == 1){
                        try {
                            mmOutputStream.write('1');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }else {
                    if (state == 1){
                        try {
                            mmOutputStream.write('2');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }
            }
        });




        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (btn2.isChecked()) {
                    if (state == 1){
                        try {
                            mmOutputStream.write('3');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }else {
                    if (state == 1){
                        try {
                            mmOutputStream.write('4');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }  //method to turn off
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (btn3.isChecked()) {
                    if (state == 1){
                        try {
                            mmOutputStream.write('5');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }else {
                    if (state == 1){
                        try {
                            mmOutputStream.write('6');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }  //method to turn off
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (btn4.isChecked()) {
                    if (state == 1){
                        try {
                            mmOutputStream.write('7');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }else {
                    if (state == 1){
                        try {
                            mmOutputStream.write('8');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }//method to turn off
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (btn5.isChecked()) {
                    if (state == 1){
                        try {
                            mmOutputStream.write('9');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }else {
                    if (state == 1){
                        try {
                            mmOutputStream.write('0');
                        }catch (IOException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(AutomationActivity.this,
                                    "Connection not established with your home",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else
                        Toast.makeText(AutomationActivity.this,
                                "Connection not established with your home",
                                Toast.LENGTH_LONG).show();
                }
            }
        });

        btnDis.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Disconnect(); //close connection
            }
        });

    }

    @Override
    public void onBackPressed() {
        Disconnect();
        super.onBackPressed();
    }

    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                msg("Disconnected");
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { msg("Error");}
        }
        state=0;
        finish(); //return to the first layout

    }


    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }


    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(AutomationActivity.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                    mmOutputStream = btSocket.getOutputStream();
                    mmInputStream = btSocket.getInputStream();
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                state=0;
                finish();
            }
            else
            {
                msg("Connected.");
                state=1;
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.abou) {
            Intent intent=new Intent(getApplicationContext(),AboutUs.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
